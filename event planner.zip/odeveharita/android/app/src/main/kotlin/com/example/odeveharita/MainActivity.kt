package com.example.odeveharita

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
